<?php
///////////////////////////////////////////////////////////////////////////////////////////
/////////// Author    : Reza Salehi
///////////	Contact   : zaalion@yahoo.com
/////////// Copyright : free for non-commercial use . 
///////////////////////////////////////////////////////////////////////////////////////////

	class html2word
	{
		///////////////////////////////////////////////////////////////////////////////////////////
		//---- Class Properties
		///////////////////////////////////////////////////////////////////////////////////////////
		
		var $uniq; 		//---- Array which holds page words.
		var $coun; 		//---- Array which holds word numbers.
		var $total;		//---- Number of words in a page or file.
		var $unum;		//---- Number of unique words in a page or file.
		
		///////////////////////////////////////////////////////////////////////////////////////////
		//---- Private variables
		///////////////////////////////////////////////////////////////////////////////////////////
		
		var $all;
		var $str;
		var $mm;
		var $f;
		
		///////////////////////////////////////////////////////////////////////////////////////////
		//---- Class constructor which initialize internal variables and runs main method of class.
		///////////////////////////////////////////////////////////////////////////////////////////
		
		function html2word($url, $max, $filter)
		{
			$this->f=$filter;
			$this->mm=$max;
			if(substr($url,0,4)=="http")
				$mode='u';
			else
				$mode='f';
			if($mode=='u')
			{
				$fp = fopen ($url, "r");
				if($fp)
				{
					while(!feof($fp))
					{
						$contents.= fgetss ($fp,1024);
					}
				}
				else
				{
					$this->str='';
				}
			}
			else if($mode=='f')
			{
				
				$fp = fopen ($url, "r");
				if($fp)
				{
					$contents = fread ($fp, filesize ($url));
				}
				else
				{
					$contents='';
				}
			}
			else
			{
				$contents='';
			}
			$j=0;
			for($i=0;$i<strlen($contents);$i++)
				{
					$char=ord($contents[$i]);
					if( ($char>=97 && $char<=122) || ($char>=65 && $char<=90) || ($char>=48 && $char<=57) || $char==32 || chr($char)=='$' || chr($char)=='.')
					{	
						$this->str.=chr($char);
					}
				}
			$this->getstat();
		}
		
		///////////////////////////////////////////////////////////////////////////////////////////
		//---- main function which parses web page or file and returnes 2 arrays which hold -
		//	   list of unique words and number of them.
		///////////////////////////////////////////////////////////////////////////////////////////
		
		function getstat()
		{	
			$word=explode(" ",$this->str);
			sort($word);
			$j=1;
			$k=0; 	
 			$forbidden='0';	
 			for($i=0;$i<count($word);$i++)			
			{				
 				if(strlen($word[$i])>$this->mm || $word[$i]==' ' || ord($word[$i])==13 || ord($word[$i])==10 || ord($word[$i])==0)
				{
					$i++;
					continue;
				}
				if($this->f=='1')
				{	
					if(strlen($word[$i])<3)
						$word[$i]=' ';
					$word[$i]=str_replace(' ','',$word[$i]);
					$mix=$word[$i];
					switch(strtolower($mix))
					{
						case "i":
						case "hi":
						case "hey":
						case "next":
						case "last":
						case "too":
						case "who":
						case "two":
						case "yes":
						case "out":
						case "what":
						case "one":
						case "new":
						case '':
						case "all":
						case "more":
						case "must":
						case "only":
						case "just":
						case "your":
						case "as":
						case "may":
						case "and":
						case "www":
						case "it":
						case "on":
						case "you":
						case "am":
						case "is":
						case "are":
						case "was":
						case "were":
						case "be":
						case "have":
						case "has":
						case "had":
						case "been":
						case "they":						
						case "that":
						case "then":
						case "or":
						case "into":
						case "in":
						case "to":
						case "his":
						case "her":
						case "he":
						case "she":
						case "do":
						case "does":
						case "away":
						case "to":
						case "no":						
						case "but":					
						case "a":
						case "&amp;":
						case "now":
						case "will":
						case "about":
						case "at":						
						case "not":						
						case "by":				
						case "the":
						case "for":
						case "with":
						case "this":
						case "from":
						case "of":
						case "our":
							$forbidden='1';
							break;
						default:
							$forbidden='0';							
					}
				}
			
			if($forbidden=='0')
				{
				while(($word[$i]==$word[$i+1]))
					{
						$i++;
						$j++;
					}
				$this->uniq[$k]=$word[$i];
				$this->coun[$k++]=$j;
				$j=1;
				}
			}
			$this->unum=count($this->uniq);
			$this->total=count($word);
		}
		
		///////////////////////////////////////////////////////////////////////////////////////////
		//---- this is a simple function which shows the result. but you can get array 'uniq' &
		//	   'coun' and manually print them .
		///////////////////////////////////////////////////////////////////////////////////////////
		
		function show()
		{			
			for($i=0;$i<count($this->uniq);$i++)
			{
				$zero=str_repeat('0',5-strlen($this->coun[$i]));
				$this->coun[$i]=$zero.$this->coun[$i];
				$this->all[$i]=$this->coun[$i]." ---> ".$this->uniq[$i];
			}
			sort($this->all);
			for($i=count($this->all);$i>-1;$i--)
			{				
				print $this->all[$i]."<br>";
			}
		}
	}
?>
