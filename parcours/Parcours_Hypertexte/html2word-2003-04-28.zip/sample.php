<?php
	//set_time_limit(120);
	include("html2word.class.php");
	
	$url="http://www.yahoo.com"; 					// url to get file or html page from.
	$max_length=15;				 					// max length of words you want to get.
	$filter='1';								   // determine if you want to filter unnecessary words like 'am','is',....
	
	$f=new html2word($url, $max_length, $filter);     // make new instance of object html2word.
	
	$f->show()."<br><br>";						   // call method 'show' to get result.
	
	$str=implode(' ', $f->uniq);					   // gets 'uniq' property of object which holds list of unique words and print it.
	print "unique words list : ".$str."<br>";
	
	$str=implode(' ', $f->coun);					   // gets 'coun' property of object which holds list of unique words and print it.
	print "unique words numbers list : ".$str."<br>";
	
	print "Number of words : ".$f->total."<br>";					   	   // number of words in the file or html page.
	
	print "Number of unique words : ".$f->unum."<br>";					   // number of unique words in the page.
?>